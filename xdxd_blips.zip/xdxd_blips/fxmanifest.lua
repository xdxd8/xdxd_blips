fx_version "badacious"

game { "gta5"}

author 'xdxd'
description 'Blips'
version '1.0.0'

client_scripts {
    "client.lua",
}