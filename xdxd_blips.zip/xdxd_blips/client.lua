local blips = {
    -- MINTA: {title="Mit írjon ki blip névnek", colour=https://docs.fivem.net/docs/game-references/blips/, id=https://docs.fivem.net/docs/game-references/blips/, x=, y=, z=},

     {title="xd.xd", colour=5, id=446, x = -347.291, y = -133.370, z = 38.009},
     {title="xd.xd", colour=30, id=108, x = 260.130, y = 204.308, z = 109.287}
  }
      
Citizen.CreateThread(function()

    for _, info in pairs(blips) do
      info.blip = AddBlipForCoord(info.x, info.y, info.z)
      SetBlipSprite(info.blip, info.id)
      SetBlipDisplay(info.blip, 4)
      SetBlipScale(info.blip, 1.0)
      SetBlipColour(info.blip, info.colour)
      SetBlipAsShortRange(info.blip, true)
	  BeginTextCommandSetBlipName("STRING")
      AddTextComponentString(info.title)
      EndTextCommandSetBlipName(info.blip)
    end
end)